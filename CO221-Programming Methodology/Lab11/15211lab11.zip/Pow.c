// Week10_Pow.c
// Compute the nth power of x, where
// n is a non-negative integer.
#include <stdio.h>

double mypow(double x, int n);

int main(void) {
	double x;
	int n;

	printf("Enter x and n: ");
	scanf("%lf %d", &x, &n);

	printf("mypow(%f, %d) = %f\n", x, n, mypow(x, n));
	return 0;
}

// Compute the nth power of x.
// Precond: n >= 0
double mypow(double x, int n) {//x=base number,n=power number
	// to be completed
 if(n !=0){
   return (x*mypow(x,n-1));//x^n=x*x^(n-1) can get power of number by this function
 }else if (n = 0){
    return 1;
 }else{
    return 1;
  }
}

