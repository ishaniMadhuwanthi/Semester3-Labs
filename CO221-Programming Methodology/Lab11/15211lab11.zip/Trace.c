// Week10_Trace.c
// Tracing exercises
#include <stdio.h>

void mystery1(int num);
void mystery2(int num);

int main(void) {
	int num;

	printf("Enter positive intenger: ");
	scanf("%d", &num);

	printf("Output of mystery1(%d): ", num);
	mystery1(num);
	printf("\n");

	printf("Output of mystery2(%d): ", num);
	mystery2(num);
	printf("\n");

	return 0;
}

void mystery1(int num) {
	if (num>0) {
		printf("%d", num%10);
		mystery1(num/10);
	}
}

void mystery2(int num) {
	if (num>0) {
		mystery2(num/10);
		printf("%d", num%10);
	}
}

