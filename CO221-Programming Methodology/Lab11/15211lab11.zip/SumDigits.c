// Week10_SumDigits.c
// Sum up all digits in an integer.

#include <stdio.h>

int sum_digits(int num);

int sumArray(int array[100], int num);

int main(void) {
	int num;

	printf("Enter a non-negative integer: ");
	scanf("%d", &num);
     
      if(num<0){
          printf("enter a positive number\n");//to check whether it is positive number or negative number
       }else{
	printf("Sum of its digits = %d\n", sum_digits(num));
       }  
	return 0;
}

// Return sum of digits in integer n
// Pre-cond: n >= 0
int sum_digits(int num) {
 //recursive function for find sum of digits the given number
   
  if(num == 0){
      return 0 ;
   }else{
      return((num%10) + sum_digits(num / 10));
   }
}


