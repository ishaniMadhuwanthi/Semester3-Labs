#include <stdio.h>

int gcd(int num1, int num2);

int main(void) {
	int num1, num2;

	printf("Enter two integers: ");
	scanf("%d %d", &num1, &num2);

	printf("gcd(%d, %d) = %d\n", num1, num2, gcd(num1, num2));
	return 0;
}

// Compute the greatest common divisor of a and b
// Precond: a and b non-negative, not both zero
int gcd(int num1, int num2) {
	// to be completed

if(num2==0){
   return num1;
}else{
  return gcd(num2,num1%num2);
  }

}

