/*
E/15/211
Madhuwanthi S.A.I.
*/

#include<stdio.h>
#include<math.h>

int main(){

 int columns,rows;
 int i,j,k,p,x,g,r,b;
//p-paddings,r-red,b-blue,g-green

scanf("%d %d\n",&columns,&rows);//to get the size of image
printf("%d %d\n",columns,rows);

  for(i=1;i<=rows;i++)
 {
   for(j=1;j<=columns;j++){
     scanf("%d %d %d\n",&r,&g,&b);
          r=255-r;
          g=255-g;
          b=255-b;
     printf("%d %d %d\n",r,g,b);
 }

  p=4-(3*columns % 4);
    
     if(p==4)
     {
       printf("\n");
      } 
     else 
      
      {
        for(k=1;k<=p;k++){
        
         scanf("%d",&x);
         printf("%d\n",x);
        }
        
       }
    }   
 
return 0;

}


