/*
*Madhuwanthi S.A.I.
*E/15/211
*CO223
*calculate the electricity bill in domestic purposes
*/

#include <stdio.h>

int main(){
 int units; //no of units that is used
 double cost; // cost for used units

 printf("Enter the number of units used: ");
 scanf("%d",&units);

 if (units>=180){
    cost=3523.50+540+45*(units-180);
    printf("The cost is %.2f for %d units.\n",cost,units);
}else if (units>=120){
    cost=32*(units-120)+480+1603.5;
    printf("The cost is %.2f for %d units.\n",cost,units);
}else if (units>=90){
    cost=861+480+27.75*(units-90);
    printf("The cost is %.2f for %d units.\n",cost,units);
}else if (units>=60){
    cost=(7.85*60)+90+10*(units-60);
    printf("The cost is %.2f for %d units.\n",cost,units);
}else if (units>=30){
    cost=105+60+4085*(units-30);
    printf("The cost is %.2f for %d units.\n",cost,units);
}else if (units>=0){
    cost=30+2.50*units;
    printf("The cost is %.2f for %d units.\n",cost,units);
}else{
    printf("-1");
  } 

return 0;
}
