#include<stdio.h>
#include<string.h>
int main(){
   
 char X,Y;//player1=X,player2=Y
 char R,S,C,P,L;//R=ROCK,S=SOCKS,C=SCISSOR,P=PAPER,L=LIZARD
 
scanf("%s %s",&X, &Y);//to input two players

 if((X=='R'||X=='S'||X=='C'||X=='P'||X=='L') && (Y=='R'||Y=='S'||Y=='C'||Y=='P'||Y=='L'))
   
     if (((X=='R')&&(Y=='C'||Y=='L'))||((X=='S')&&(Y=='C'||Y=='R'))||((X=='C')&&(Y=='P'||Y=='L'))||((X=='P')&&(Y=='S'||Y=='R'))||((X=='L')&&(Y=='S'||Y=='P'))){
      printf("Player1 wins\n");

      }else if (((X=='R')&&(Y=='S'||Y=='P'))||((X=='S')&&(Y=='P'||Y=='L'))||((X=='C')&&(Y=='R'||Y=='S'))||((X=='P')&&(Y=='C'||Y=='L'))||((X=='L')&&(Y=='R'||Y=='C'))){
      printf("Player2 wins\n");

      }else{
      printf("Tie\n");
    }
   
 else{
      printf("Wrong input\n");
}
return 0;

}
       
