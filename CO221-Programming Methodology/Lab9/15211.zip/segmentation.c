// Fix the bugs

#include<stdio.h>
#include<stdlib.h>

struct Node 
{
	int value;
	struct Node * next;
};

typedef struct Node Node;

int main()
{
	Node head;
	Node* iterator = &head;
        
        iterator = (Node *)malloc(sizeof(Node));

// Create a liked list with 10 elements

  iterator = malloc(sizeof(Node));
  iterator->value = 0;

  iterator->next = malloc(sizeof(Node));
  iterator->next->value = 1;

  iterator->next->next = malloc(sizeof(Node));
  iterator->next->next->value = 2;

  iterator->next->next->next = malloc(sizeof(Node));
  iterator->next->next->value = 3;

  iterator->next->next->next->next = malloc(sizeof(Node));
  iterator->next->next->next->value = 4;

  iterator->next->next->next->next->next = malloc(sizeof(Node));
  iterator->next->next->next->next->value = 5;

  iterator->next->next->next->next->next->next = malloc(sizeof(Node));
  iterator->next->next->next->next->next->value = 6;

  iterator->next->next->next->next->next->next->next = malloc(sizeof(Node));
  iterator->next->next->next->next->next->next->value = 7;

  iterator->next->next->next->next->next->next->next->next = malloc(sizeof(Node));
  iterator->next->next->next->next->next->next->next->value = 8;

  iterator->next->next->next->next->next->next->next->next->next = malloc(sizeof(Node));
  iterator->next->next->next->next->next->next->next->next->value = 9;

iterator->next->next->next->next->next->next->next->next->next = NULL;

	// Printing the values 
	iterator = &head;

	while(iterator->next != NULL)
	{
		printf("Value %d\n", iterator->value);
 }
 }

